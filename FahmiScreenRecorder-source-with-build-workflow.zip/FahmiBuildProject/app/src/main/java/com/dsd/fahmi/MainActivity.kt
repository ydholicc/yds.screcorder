package com.dsd.fahmi

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.content.Context
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private const val RED = 0xFFF43F50.toInt()
private const val INK = 0xFF172033.toInt()
private const val MUTED = 0xFF6B778C.toInt()
private const val BG = 0xFFF7F8FC.toInt()

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("fahmi_local", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFFFFF8F9.toInt()
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (prefs.getBoolean("logged_in", false)) home() else welcome()
    }

    private fun base(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
            setBackgroundColor(BG)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        text(title, 28, INK, true)
        subtitle?.let { text(it, 14, MUTED, false) }
    }

    private fun welcome() {
        base("Fahmi", "Screen Recorder  •  oleh dsd")
        space(28)
        card {
            text("Rekam. Simpan. Bagikan.", 22, INK, true)
            text("Perekam layar modern untuk Android 15 ke atas.", 14, MUTED, false)
        }
        space(16)
        button("Masuk") { login() }
        button("Buat akun lokal", false) { register() }
        text("Akun disimpan di perangkat ini. Tidak ada sinkronisasi online.", 12, MUTED, false)
    }

    private fun register() {
        base("Buat akun", "Profil lokal di perangkat ini")
        val name = field("Nama pengguna")
        val email = field("Email (opsional)", InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pass = field("Kata sandi", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val confirm = field("Ulangi kata sandi", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        button("Daftar") {
            val n = name.text.toString().trim(); val p = pass.text.toString(); val c = confirm.text.toString()
            when {
                n.length < 3 -> toast("Nama pengguna minimal 3 karakter")
                p.length < 8 -> toast("Kata sandi minimal 8 karakter")
                p != c -> toast("Kata sandi belum sama")
                prefs.contains("password_hash") -> toast("Akun lokal sudah ada. Masuk atau reset data aplikasi untuk membuat akun baru.")
                else -> {
                    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                    prefs.edit().putString("username", n).putString("email", email.text.toString().trim())
                        .putString("salt", salt.toHex()).putString("password_hash", hash(p, salt))
                        .putBoolean("logged_in", true).apply()
                    home()
                }
            }
        }
        button("Kembali", false) { welcome() }
    }

    private fun login() {
        base("Masuk", "Masuk ke profil lokal Fahmi")
        val name = field("Nama pengguna")
        val pass = field("Kata sandi", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        button("Masuk") {
            val salt = prefs.getString("salt", null)?.hexToBytes()
            val expected = prefs.getString("password_hash", null)
            if (salt == null || expected == null) toast("Belum ada akun. Buat akun terlebih dahulu.")
            else if (name.text.toString().trim() != prefs.getString("username", "") || !constantTimeEquals(hash(pass.text.toString(), salt), expected)) toast("Nama pengguna atau kata sandi salah")
            else { prefs.edit().putBoolean("logged_in", true).apply(); home() }
        }
        button("Buat akun", false) { register() }
        button("Kembali", false) { welcome() }
    }

    private fun home() {
        base("Fahmi", "Screen Recorder  •  Halo, ${prefs.getString("username", "Pengguna")}")
        space(12)
        card {
            text("Siap merekam?", 20, INK, true)
            text("Atur kualitas sesuai kemampuan perangkat.", 13, MUTED, false)
            space(8)
            text("1440p target  •  60 FPS target", 14, RED, true)
            text("Nilai aktual bergantung pada perangkat.", 12, MUTED, false)
        }
        space(12)
        button("●   Mulai Rekam") { toast("Mesin perekaman belum diaktifkan pada build awal.") }
        button("Pengaturan rekaman", false) { settings() }
        button("Editor video", false) { feature("Editor video", "Pemotongan, penggabungan, dan pratinjau video perlu diimplementasikan.") }
        button("Watermark", false) { feature("Watermark Fahmi", "Pengaturan watermark disiapkan; penempelan watermark ke video belum aktif.") }
        button("Cadangan / Backup", false) { feature("Backup", "Ekspor dan pemulihan pengaturan/profil perlu implementasi dan pengujian.") }
        button("Jadwal rekaman", false) { feature("Jadwal", "Penjadwalan antarmuka disiapkan. Rekaman otomatis harus mematuhi izin sistem dan konfirmasi pengguna.") }
        button("Kompres video", false) { feature("Kompres video", "Kompresi video belum aktif; perlu pipeline encoder dan uji kualitas.") }
        button("File saya", false) { feature("File saya", "Galeri rekaman akan menampilkan video yang dibuat aplikasi setelah mesin perekam selesai.") }
        button("Keluar akun", false) { prefs.edit().putBoolean("logged_in", false).apply(); welcome() }
        text("Versi 1.0.0 • Android 15+ • dsd", 12, MUTED, false)
    }

    private fun settings() {
        base("Pengaturan", "Preferensi lokal")
        val resolution = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1440p (default)", "1080p", "720p")) }
        val fps = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("60 FPS (default)", "30 FPS")) }
        text("Resolusi", 14, INK, true); root.addView(resolution, matchWrap())
        text("Frame rate", 14, INK, true); root.addView(fps, matchWrap())
        val watermark = CheckBox(this).apply { text = "Tampilkan watermark Fahmi (opsi)"; setTextColor(INK) }
        root.addView(watermark)
        val internalAudio = CheckBox(this).apply { text = "Audio internal jika diizinkan"; isChecked = true; setTextColor(INK) }
        root.addView(internalAudio)
        button("Simpan pengaturan") {
            prefs.edit().putString("resolution", resolution.selectedItem.toString()).putString("fps", fps.selectedItem.toString())
                .putBoolean("watermark", watermark.isChecked).putBoolean("internal_audio", internalAudio.isChecked).apply()
            toast("Pengaturan disimpan di perangkat")
        }
        button("Kembali", false) { home() }
    }

    private fun feature(title: String, description: String) {
        base(title, "Fahmi Screen Recorder")
        card { text(description, 15, INK, false) }
        space(12)
        button("Kembali ke Beranda") { home() }
    }

    private fun field(hintText: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this).apply {
            hint = hintText; inputType = type; textSize = 15f; setTextColor(INK); setHintTextColor(MUTED)
            setPadding(dp(14), dp(8), dp(14), dp(8)); background = rounded(Color.WHITE, 14, 0xFFE7EAF1.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, dp(54)); lp.topMargin = dp(10); root.addView(e, lp)
        return e
    }

    private fun button(label: String, primary: Boolean = true, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(if (primary) Color.WHITE else INK)
            background = rounded(if (primary) RED else Color.WHITE, 16, if (primary) RED else 0xFFE7EAF1.toInt())
            setPadding(dp(12), dp(15), dp(12), dp(15)); isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10); root.addView(b, lp)
    }

    private fun card(content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(Color.WHITE, 22, 0xFFE9ECF3.toInt()) }
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        box.content()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) {
        root.addView(TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(4)) }, matchWrap())
    }
    private fun LinearLayout.text(value: String, size: Int, color: Int, bold: Boolean) {
        addView(TextView(this@MainActivity).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(4)) }, matchWrap())
    }
    private fun space(n: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(n))) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun rounded(color: Int, radius: Int, stroke: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded.toHex()
    }
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}
