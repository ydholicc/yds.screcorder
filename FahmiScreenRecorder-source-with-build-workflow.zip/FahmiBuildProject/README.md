# Fahmi Screen Recorder — source scaffold
Author: dsd

## Status
This is an early Android source project scaffold for Android 15+ (min/target SDK 35), with a light UI and red accent. It is **not a finished screen recorder** and no APK has been built or tested in this environment.

### Implemented in this scaffold
- Native Android UI for welcome, local account registration/login, home, and settings.
- One local profile stored in app-private SharedPreferences.
- Password hashing with PBKDF2-HMAC-SHA256 and random per-account salt (not plaintext password storage).
- Local preferences for resolution, FPS, watermark toggle, and internal audio preference.
- UI entry points for editor, watermark, backup, schedule, compression, and files, clearly marked as not yet implemented.
- Android 15 SDK targeting and initial media-projection foreground-service permissions in manifest.

### Not yet implemented / not tested
- Actual MediaProjection recording service, foreground notification and lifecycle handling.
- Capturing internal playback audio; Android and the source app can prohibit capture.
- Real editor, watermark rendering, backup export/import, scheduled recording, compression/encoding, and recording gallery.
- Device compatibility, performance, accessibility, and security testing.

## Build requirements
Install Android Studio with Android SDK Platform 35 and a compatible JDK (17 recommended for AGP 8.7.3). Open this folder in Android Studio and sync Gradle. Internet access may be needed to download Gradle and Android Gradle Plugin dependencies. Then build the debug APK from Build > Build Bundle(s) / APK(s) > Build APK(s).

This environment had Java 21 and Kotlin compiler, but no Gradle executable/wrapper, Android SDK, adb, aapt, or apksigner, so a real APK build/sign/install test could not be performed here.

## Important design notes
- `minSdk = 35` means Android 14 and earlier cannot install this build.
- 1440p/60 FPS are desired defaults, not guaranteed; supported sizes and frame rates must be queried from the device and recording encoder.
- The current local-account implementation supports one local profile. Clearing app data removes the profile; it does not sync across devices.
- For a public release, review Android MediaProjection consent/foreground-service rules and encrypt any exported backups containing private data.

## Build APK using GitHub Actions (no Android Studio needed on your phone)

This project includes `.github/workflows/android.yml` to build a **debug APK** in GitHub's cloud runner.

1. On GitHub, create a new repository (for example `FahmiScreenRecorder`).
2. Upload the **contents** of this project folder to the repository root. Ensure `app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, and `.github/workflows/android.yml` are at the root (not nested inside an extra folder).
3. Open the repository's **Actions** tab and select **Build Fahmi APK**.
4. Tap **Run workflow** (or push to the `main` branch) and wait for the workflow to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `Fahmi-ScreenRecorder-debug-apk`.
6. Extract the ZIP artifact to get `app-debug.apk`, then install it on an Android 15+ device if Android permits installation from that source.

The debug APK is signed with a debug key for testing; it is not a production release. Do not publish it as a trusted release without review and signing.

### Important limitations

A successful build only proves that the current source compiles. The current project is a starter UI/account scaffold. Recording, internal audio capture, editor, watermark rendering, backup/restore, scheduled recording, and compression are not implemented yet. These must not be advertised as working until implemented and tested on real devices.
